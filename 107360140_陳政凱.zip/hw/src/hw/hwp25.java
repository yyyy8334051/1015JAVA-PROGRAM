package hw;

public class hwp25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		num=3;
		System.out.println("�ܼ�num���ȬO:"+num);
	}

}
