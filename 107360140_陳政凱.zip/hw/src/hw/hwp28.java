package hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hwp28 {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		System.out.println("�п�J�@�Ӿ��:");
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		String str1=br1.readLine();
		int num=Integer.parseInt(str1);
		System.out.println("�A��J���Ʀr�O:"+num);
		System.out.println("�п�J�r��:");
		BufferedReader br2=new BufferedReader(new InputStreamReader(System.in));
		String str2=br2.readLine();
		System.out.println("�A��J���Ʀr�O:"+str2);
	}

}
