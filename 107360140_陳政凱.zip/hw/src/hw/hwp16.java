package hw;

public class hwp16 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println('a');
		System.out.println("�w��ϥ�JAVA!");
		System.out.println(123);
	}
}
