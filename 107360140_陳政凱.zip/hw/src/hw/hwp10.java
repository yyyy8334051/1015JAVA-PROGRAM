package hw;

public class hwp10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("�w��ϥ�JAVA!");
		System.out.println("�w��ϥ�JAVA!");
	}

}
