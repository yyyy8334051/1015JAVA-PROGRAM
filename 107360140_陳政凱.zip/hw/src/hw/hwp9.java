package hw;

public class hwp9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("�w��ϥ�JAVA!");
		System.out.print("�w��ϥ�JAVA!");
	}

}
