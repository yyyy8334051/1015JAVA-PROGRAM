package hw;

public class hwp181 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("��{�X�ϱ׽u:\\");
		System.out.println("��{�X��޽u\'");
	}

}
